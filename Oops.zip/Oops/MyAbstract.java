package Oops;

public abstract class MyAbstract {
    abstract void getMyDetails();
}
